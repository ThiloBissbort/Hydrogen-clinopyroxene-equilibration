%This uses T, P, and fH2O data to compute the solubility of H2O (c_H2O) in
%clinopyroxene 

clear variables

%% input
filename = 'output.xlsx';
A = 7.144; %ppm bar-1
n = 0.5;
dV = 7.3*1E-6; %m³ mol-1
dE = 21.2*1000; %J mol-1
R = 8.314; %J K-1 mol-1

%references for input values used
ref_A = 'Keppler, H.; Bolfan-Casanova, N. (2006) In: Reviews in Mineralogy and Geochemistry 62 (1), S. 193–230.';
ref_n = 'Liu, H.; Yang, X. (2020) In: Geochimica et Cosmochimica Acta 286, S. 355–379.';
ref_dV = 'Liu, H.; Yang, X. (2020) In: Geochimica et Cosmochimica Acta 286, S. 355–379.';
ref_dE = 'Liu, H.; Yang, X. (2020) In: Geochimica et Cosmochimica Acta 286, S. 355–379.';

%% open file
data = readmatrix(filename,'Sheet',1);
T_C = data(:,5);
T_K = data(:,4);
P_kbar = data(:,7);
f_H2O_bar = data(:,12);
P_bar = P_kbar*1E+3;
P_GPa = P_kbar/10;
nodes = numel(T_K);
f_H2O_bar = f_H2O_bar*1E-5;

%% calculate solubitiy c (H2O ppm)
c_H2O = zeros(1,nodes);
for i = 1:nodes
    c_H2O(i) = A*(f_H2O_bar(i)^n)*exp(-(dE+P_bar(i)*dV)/(R*T_K(i)));
end

%% plot
scatter3(T_C,P_GPa,c_H2O,'o','MarkerFaceColor','k','MarkerEdgeColor','k');
line(T_C,P_GPa,c_H2O,'Color','k')
xlabel('temperature °C')
ylabel('pressure GPa')
zlabel('solubility (H_2O ppm)')

%% write data
header = {'cH_2O (ppm)'};
data = c_H2O';
data = table(data);
writetable(data,filename,'Sheet',1,'Range','M1');
writecell(header,filename,'Sheet',1,'Range','M1');

header_info = {'solubility calculation after Keppler, H.; Bolfan-Casanova, N. (2006) In: Reviews in Mineralogy and Geochemistry 62 (1), S. 193–230. ';'filename';'A (ppm bar-1)';'n';'dV (m3 mol-1)';'dE (J mol-1)';'R (J K-1 mol-1)'};
data_info = {filename;A;n;dV;dE;R};
ref_info = {ref_A;ref_n;ref_dV;ref_dE};

writecell(header_info,filename,'Sheet',2,'Range','A14');
writecell(data_info,filename,'Sheet',2,'Range','B15');
writecell(ref_info,filename,'Sheet',2,'Range','C16');

