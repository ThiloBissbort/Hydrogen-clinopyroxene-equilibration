clear variables;

x = 3; %method of extrapolation

dT_C_interp = 1; %interpolation spacing °C
dP_kbar_interp = 1/100; %interpolation spacing kbar

T_C_add = (100:dT_C_interp:299);
P_kbar_add = (10.01:dP_kbar_interp:35);



%% load original fugacity coefficients 
%data from Shi and Saxena (1992, Am. Min. 77,1038-1049)
%format: rows = increasing T in C; columns = increasing P in kbar
load('fugacity_coefficient_H2O.mat')
load('fugacity_coefficient_CO2.mat')
load('fugacity_coefficient_CH4.mat')
load('fugacity_coefficient_H2.mat')
load('fugacity_coefficient_CO.mat')
load('fugacity_coefficient_T_C.mat')
load('fugacity_coefficient_P_kbar.mat')


%% interpolate fugacity coefficient data
%this is done by 2D interpolation over a T-P grid with certain node spacing
%determined by dT_interp and dP_interp. 

% some pre-calculations for the interpolation method
T_C_min_y = min(fugacity_coefficient_T_C); %minimum T °C of y dataset
T_C_max_y = max(fugacity_coefficient_T_C); %maximum T °C of y dataset
T_C_interp  = (T_C_min_y:dT_C_interp:T_C_max_y); %T °C used for interpolation 
T_C_final = [T_C_add,T_C_interp];

P_kbar_min_y = min(fugacity_coefficient_P_kbar); %minimum P kbar of y dataset
P_kbar_max_y = max(fugacity_coefficient_P_kbar); %maximum P kbar of y dataset
P_kbar_interp = (P_kbar_min_y:dP_kbar_interp:P_kbar_max_y); % T kbar used for interpolation
P_kbar_final = [P_kbar_interp,P_kbar_add];

% create grids for 2D interpolation
[T_C_grid,P_kbar_grid] = meshgrid(fugacity_coefficient_T_C,fugacity_coefficient_P_kbar);
[T_C_interp_grid,P_kbar_interp_grid] = meshgrid(T_C_interp,P_kbar_interp);

% 2D interpolation of fugacity coefficient data
fug_coeff_interp_H2O = interp2(T_C_grid,P_kbar_grid,fugacity_coefficient_H2O',T_C_interp_grid,P_kbar_interp_grid);
fug_coeff_interp_CO2 = interp2(T_C_grid,P_kbar_grid,fugacity_coefficient_CO2',T_C_interp_grid,P_kbar_interp_grid);
fug_coeff_interp_CH4 = interp2(T_C_grid,P_kbar_grid,fugacity_coefficient_CH4',T_C_interp_grid,P_kbar_interp_grid);
fug_coeff_interp_H2 = interp2(T_C_grid,P_kbar_grid,fugacity_coefficient_H2',T_C_interp_grid,P_kbar_interp_grid);
fug_coeff_interp_CO = interp2(T_C_grid,P_kbar_grid,fugacity_coefficient_CO',T_C_interp_grid,P_kbar_interp_grid);

% expanding fugacity coefficient range for extrapolation
% create matrices that are then added to previously interpolated matrix
% expanded in T direction
fug_coeff_addT_H2O = zeros(1,numel(T_C_add));
for i = 1:numel(T_C_add)
    for k = 1:numel(P_kbar_interp)
     fug_coeff_addT_H2O(k,i) = NaN;
     fug_coeff_addT_CH4(k,i) = NaN;
     fug_coeff_addT_CO(k,i) = NaN;
     fug_coeff_addT_CO2(k,i) = NaN;
     fug_coeff_addT_H2(k,i) = NaN;
    end
end
%expanded in P direction
for k = 1:numel(P_kbar_add)
    for i = 1:numel(T_C_final)
        fug_coeff_addP_H2O(k,i) = NaN;
        fug_coeff_addP_CH4(k,i) = NaN;
        fug_coeff_addP_CO(k,i) = NaN;
        fug_coeff_addP_CO2(k,i) = NaN;
        fug_coeff_addP_H2(k,i) = NaN;
    end
end

fug_coeff_expanded_H2O = [fug_coeff_addT_H2O,fug_coeff_interp_H2O];
fug_coeff_expanded_H2O = [fug_coeff_expanded_H2O;fug_coeff_addP_H2O];

fug_coeff_expanded_CH4 = [fug_coeff_addT_CH4,fug_coeff_interp_CH4];
fug_coeff_expanded_CH4 = [fug_coeff_expanded_CH4;fug_coeff_addP_CH4];

fug_coeff_expanded_CO = [fug_coeff_addT_CO,fug_coeff_interp_CO];
fug_coeff_expanded_CO = [fug_coeff_expanded_CO;fug_coeff_addP_CO];
 
fug_coeff_expanded_CO2 = [fug_coeff_addT_CO2,fug_coeff_interp_CO2];
fug_coeff_expanded_CO2 = [fug_coeff_expanded_CO2;fug_coeff_addP_CO2];

fug_coeff_expanded_H2 = [fug_coeff_addT_H2,fug_coeff_interp_H2];
fug_coeff_expanded_H2 = [fug_coeff_expanded_H2;fug_coeff_addP_H2];

fug_coeff_final_H2O = inpaint_nans(fug_coeff_expanded_H2O,x);
fug_coeff_final_H2O(fug_coeff_final_H2O<0) = 0;

fug_coeff_final_CH4= inpaint_nans(fug_coeff_expanded_CH4,x);
fug_coeff_final_CH4(fug_coeff_final_CH4<0) = 0;

fug_coeff_final_CO = inpaint_nans(fug_coeff_expanded_CO,x);
fug_coeff_final_CO(fug_coeff_final_CO<0) = 0;

fug_coeff_final_CO2 = inpaint_nans(fug_coeff_expanded_CO2,x);
fug_coeff_final_CO2(fug_coeff_final_CO2<0) = 0;

fug_coeff_final_H2 = inpaint_nans(fug_coeff_expanded_H2,x);
fug_coeff_final_H2(fug_coeff_final_H2<0) = 0;

figure
subplot(2,5,1)
surf(T_C_grid,P_kbar_grid,fugacity_coefficient_H2O');
xlabel('T (°C)');
ylabel('P (kbar)');
zlabel('yH_2O');
title('H_2O original data')

subplot(2,5,2)
surf(T_C_grid,P_kbar_grid,fugacity_coefficient_CH4');
xlabel('T (°C)');
ylabel('P (kbar)');
zlabel('yCH_4');
title('CH_4 original data')

subplot(2,5,3)
surf(T_C_grid,P_kbar_grid,fugacity_coefficient_CO');
xlabel('T (°C)');
ylabel('P (kbar)');
zlabel('yCO');
title('CO original data')

subplot(2,5,4)
surf(T_C_grid,P_kbar_grid,fugacity_coefficient_CO2');
xlabel('T (°C)');
ylabel('P (kbar)');
zlabel('yCO2');
title('CO_2 original data')

subplot(2,5,5)
surf(T_C_grid,P_kbar_grid,fugacity_coefficient_H2');
xlabel('T (°C)');
ylabel('P (kbar)');
zlabel('yH2');
title('H_2 original data')

subplot(2,5,6)
meshc(T_C_final,P_kbar_final,fug_coeff_final_H2O);
xlabel('T (°C)');
ylabel('P (kbar)');
zlabel('yH_2O');
title('H_2O interp + extrap')

subplot(2,5,7)
meshc(T_C_final,P_kbar_final,fug_coeff_final_CH4);
xlabel('T (°C)');
ylabel('P (kbar)');
zlabel('yCH_4');
title('CH_4 interp + extrap')

subplot(2,5,8)
meshc(T_C_final,P_kbar_final,fug_coeff_final_CO);
xlabel('T (°C)');
ylabel('P (kbar)');
zlabel('yCO');
title('CO interp + extrap')

subplot(2,5,9)
meshc(T_C_final,P_kbar_final,fug_coeff_final_CO2);
xlabel('T (°C)');
ylabel('P (kbar)');
zlabel('yCO_2');
title('CO_2 interp + extrap')

subplot(2,5,10)
meshc(T_C_final,P_kbar_final,fug_coeff_final_H2);
xlabel('T (°C)');
ylabel('P (kbar)');
zlabel('yH_2');
title('H_2 interp + extrap')


