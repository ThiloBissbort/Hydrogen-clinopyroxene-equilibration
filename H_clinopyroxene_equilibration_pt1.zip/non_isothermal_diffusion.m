%This script is set up to import a geotherm-data, that is then adjusted to
%fit a T-grid with 1°C spacing for non-isothermal modeling. 

clear variables;

tic;
%----------------------------------------------------------------------
%% Input
%--------------------------------------------------------=--------------
filename = 'output.xlsx'; %load geotherm data

r=0.45;

%Initial profile
length = 500; %length in um
dx=0.5; %spatial discretisation in um

%Arrhenius parameters for D
Q = 115.64; %activation energy in kJ/mol
D0_m2s = 5.4683E-8; %pre-exponential factor in m²/s
R = 8.3144; %gas constant in m²kg/s²molK

dTdt = 1E3; %cooling rate in °C/yrs

%import data from file
data_import = flip(readmatrix(filename,'Sheet',1));
z_m_import = data_import(:,1);
z_km_import = data_import(:,2);
T_K_import = data_import(:,4);
T_C_import = data_import(:,5);
P_GPa_import = data_import(:,6);
c_H2O_import = data_import(:,13);


%-----------------------------------------------------------------------
%% Calculate variables & Convert units & interpolate T-spacing
%-----------------------------------------------------------------------
T_C_start = round(T_C_import(1));
T_C_end = round(T_C_import(end));
dT = 1; %°C T-spacing

%interpolation of imported data
%set T grid with 1 °C spacing for interpolation
T_C_path = (round(T_C_import(1)):dT:round(T_C_import(end)));
T_C_path(1) = T_C_start;
for n = 2:(T_C_start-T_C_end+dT)
    T_C_path(n) = T_C_path(n-1)-dT;
end

T_K_path = T_C_path+273;
z_m_path = interp1(T_C_import,z_m_import,T_C_path,'PCHIP');
z_km_path = interp1(T_C_import,z_km_import,T_C_path,'PCHIP');
P_GPa_path = interp1(T_C_import,P_GPa_import,T_C_path,'PCHIP');
c_H2O_path = interp1(T_C_import,c_H2O_import,T_C_path,'PCHIP');
D_um2s_path = D0_m2s.*exp(-Q*1000./(R*(T_C_path+273.15))).*1E+12; %D in um²/s
D_m2s_path = D_um2s_path.*1E-12; %D in m²/s
dt_path = (r.*dx.*dx)./(D_um2s_path); %dt in s
nodes_path = numel(T_C_path);
time_s_elapsed = zeros(1,nodes_path);
time_s_step = zeros(1,nodes_path);
timesteps_elapsed = zeros(1,nodes_path);

time_s_elapsed(1) = dT/dTdt*(365*24*60*60);
time_s_step(1) = dT/dTdt*365*24*60*60;
for n = 2:nodes_path
    time_s_elapsed(:,n) = time_s_elapsed(n-1)+dT/dTdt*(365*24*60*60); 
    time_s_step(:,n) = dT/dTdt*365*24*60*60;
end
time_yrs_elapsed = time_s_elapsed/(365*24*60*60);
timesteps_step = round(time_s_step./dt_path);
timesteps = sum(timesteps_step);
timesteps_elapsed(1) = timesteps_step(1);
for n = 2:nodes_path
    timesteps_elapsed(n) = timesteps_elapsed(n-1)+timesteps_step(n);
end

data_path = [T_C_path',D_um2s_path',c_H2O_path',dt_path',time_s_elapsed',time_s_step',timesteps_step',timesteps_elapsed'];

%creating a new path containing now all parameters timestep-by-timestep
% T °C,D um²/s,c H2O, dt(s), timesteps elapsed,
sumofcount = zeros(1,nodes_path+1);
count = zeros(1,nodes_path);
count_timestep = zeros(1,timesteps);
data_path_real = zeros(1,4);

sumofcount(1) = 0;
for n = 1:nodes_path
    count(n) = data_path(n,7);
    for i = 1:count(n)
        data_path_real(sumofcount(n)+i,:) = data_path(n,1:4);
    end
    sumofcount(n+1) = sum(count(1:n));
end

count_timestep(1) = 1;
for n = 2:timesteps
    count_timestep(n) = count_timestep(n-1)+1; 
end
data_path_real(:,5) = count_timestep;



%calculating some more stuff
time_yrs = (T_C_start-T_C_end)/dTdt;
D0_um2s = D0_m2s*1E12; %D0 in um²/s
D_um2s = D0_m2s.*exp(-Q*1000./(R*(T_C_import+273.15))).*1E+12;
D_m2s = D_um2s.*1E-12;
Dmax_um2s = max(D_um2s);
time_sec=time_yrs*365*24*60*60;  %modelled time in s

%dt=(r*dx*dx)/(Dmax_um2s);   %maximize timestep according to the Dirichlet condition
%timesteps = round(time_sec/dt); %calculate # of timesteps as integer   
nodes_profile = ceil(length/dx)+1;     %[-] number of nodes of the profile + 2 nodes for the boundary concentrations at each side

% dc_left = c_left_start-c_left_end;
% dc_right = c_right_start-c_right_end;
% c_left_step = dc_left/(timesteps-1);
% c_right_step = dc_right/(timesteps-1);


%-----------------------------------------------------------------------
%% Create Initial Profile
%-----------------------------------------------------------------------

dist = zeros(nodes_profile,1);
conc_initial = zeros(nodes_profile,1);
dist(1) = 0;
for i = 2:nodes_profile
    dist(i) = dist(i-1)+dx;
end
for i = 1:nodes_profile
    conc_initial(i) = c_H2O_path(1);
end
conc_initial(1) = c_H2O_path(1);
conc_initial(nodes_profile) = c_H2O_path(1);

%------------------------------------------------------------------------
%% Allocate arrays
%------------------------------------------------------------------------
Ds = zeros(1,nodes_profile);
time_save_yrs = zeros(1,timesteps);
time_save_s = zeros(1,timesteps);
T_save_C = zeros(1,timesteps);
D_save_um2s = zeros(1,timesteps);
c_left_save = zeros(1,timesteps);
c_right_save = zeros(1,timesteps);
dt_save = zeros(1,timesteps);
%------------------------------------------------------------------------
%% Finite Difference Scheme
%------------------------------------------------------------------------
conc_fit = conc_initial;
conc_old=conc_initial;


for l=1:timesteps         %start time loop
    
    
    
    %first, store current concentrations 
    for k=1:nodes_profile          %start spatial loop over all nodes
        conc_old(k)=conc_fit(k);  %store current value of each node
    end                   %end spatial loop over all nodes       
    
    
   
        for k = 1:nodes_profile
            Ds(k) = data_path_real(l,2); % um2 s-1
        end
        
        %load parameters from matrix
        dt = data_path_real(l,4);
        conc_fit(1) = data_path_real(l,3);
        conc_fit(end) = data_path_real(l,3);
        %save some values for plots
        D_save_um2s(l) = Ds(1);
        dt_save(l) = dt;
        time_save_yrs(l) = (sum(dt_save)/(365*24*60*60));
        time_save_s(l) = sum(dt_save);
        T_save_C(l) = data_path_real(l,1);
        c_left_save(l) = conc_fit(1);
        c_right_save(l) = conc_fit(end);

    
    %now calculate new concentration values for the current timestep
    for k=2:nodes_profile-1          %start spatial loop over inner nodes 
        %conc_fit(k)=conc_old(k)+((D(k).*dt/(dx^2))*(conc_old(k-1)-(2*conc_old(k))+conc_old(k+1)));
        %half grid method:
        conc_fit(k)=conc_old(k)+(dt/dx^2)*(((Ds(k-1)+Ds(k))/2)*conc_old(k-1)-(((Ds(k-1)+Ds(k))/2)+((Ds(k+1)+Ds(k))/2))*conc_old(k)+((Ds(k+1)+Ds(k))/2)*conc_old(k+1));
    end                   %end spatial loop over inner nodes
        
    %calculate boundary nodes
    conc_fit(1) = conc_fit(1);
    conc_fit(end) = conc_fit(end);
    
   
    
end                      %end time loop




%--------------------------------------------------------------------------
%% Additional calculations
%-------------------------------------------------------------------------
D_save_m2s = D_save_um2s*1E-12;
log_D_T_m2s = log10(D_save_m2s);
T_K_10000 = 10000./(T_save_C+273.15);
log_D_temp_m2s = log10(D_save_m2s);


%------------------------------------------------------------------------
%% Plot 
%-------------------------------------------------------------------------
figure(1)
subplot(2,2,1)
plot(T_K_10000,log_D_T_m2s,'-','LineWidth',3);
xlabel('10,000/T(K)')
ylabel('log_{10}D in m²/s')

subplot(2,2,2)
plot(data_path(:,5)/(365*24*60*60),log10(data_path(:,2)*1E-12),'-','LineWidth',3)
xlabel('time (yrs)')
ylabel('log_{10}D in m²/s')

subplot(2,2,3)
plot(data_path(:,5)/(365*24*60*60),data_path(:,3),'-','LineWidth',3);
xlabel('time (yrs)')
ylabel('boundary concentration')
hold off;

subplot(2,2,4)
plot(dist,conc_initial,'--','LineWidth',3,'Color','k')
hold on;
plot(dist,conc_fit,'o-','MarkerSize',4,'MarkerFaceColor',rand(1,3),'MarkerEdgeColor','k')
xlim([dist(1)-20,dist(end)+20])
whatisthis = [conc_fit;conc_initial];
c_min = min(whatisthis);
c_max = max(whatisthis);
ylim([c_min-c_max*0.1,c_max+c_max*0.1])
xlabel('distance (\mum)')
ylabel('concentration')
legend('initial','model')



hold on;

toc;
%--------------------------------------------------------------------------
%% Write to file
%--------------------------------------------------------------------------
header = {'Diffusion modeling parameters'};
header_info = {'filename';'r';'profile length (um)';'dx (um)';'Q (kJ mol-1)';'D0 (m2 s-1)';'dT/dt (°C/yrs)'};
data_info = {filename;r;length;dx;Q;D0_m2s;dTdt};

writecell(header,filename,'Sheet',2,'Range','A22');
writecell(header_info,filename,'Sheet',2,'Range','A23');
writecell(data_info,filename,'Sheet',2,'Range','B23');

header_data_path = {'T (°C)','D (um2 s-1)','cH2O (ppm)','dt (s)','time passed (s)','time (s)','timesteps','timesteps passed'}; 
output_path = table(data_path);

writetable(output_path,filename,'Sheet',3,'Range','A1');
writecell(header_data_path,filename,'Sheet',3,'Range','A1');

header_profiles = {'initial x (um)','initial conc','fit x (um)','fit conc'};
output_profiles = [dist,conc_initial,dist,conc_fit];

writematrix(output_profiles,filename,'Sheet',4,'Range','A2');
writecell(header_profiles,filename,'Sheet',4,'Range','A1');


