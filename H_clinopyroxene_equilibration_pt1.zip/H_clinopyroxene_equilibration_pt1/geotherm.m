%geotherm calculations after Scalter 1980

clear variables;

%% input

filename = 'output';
choice = 1; %use test(0), continental(1), or oceanic(2) setting

%geotherm parameters

if choice == 0
    % TEST
    %crust
    thickness_crust = 35; %km 
    density_crust = 2830; %kg/m³
    T0_C = 10; %°C surface temperature
    q0 = 86; %mW m-2 heat flow surface 
    k1 = 2.51; %W m-1 K-1 thermal conductivity crust
    hr_km = 10; %km
    %mantle
    thickness_mantle = 90;
    density_mantle = 3380; %kg/m³
    qr = 25.1; %mW m-2 heat flow base of crust 
    k2 = 3.35; %W m-1 K-1 thermal conductivity mantle
    ref_thickness_crust = 'Philpotts, A.; Ague, J. (2009): Principles of Igneous and Metamorphic Petrology. Cambridge: Cambridge University Press.';
    ref_density_crust = 'Carlson, R. L.; Herrick, C. N. (1990): Densities and porosities in the oceanic crust and their variations with depth and age. In: J. Geophys. Res. 95 (B6), S. 9153';
    ref_surfacetemp = 'arbitrary';
    ref_heat_flowsurface = 'Sclater, J. G.; Jaupart, C.; Galson, D. (1980): The heat flow through oceanic and continental crust and the heat loss of the Earth. In: Rev. Geophys. 18 (1), S. 269.';
    ref_thermalconductivity_crust = 'Sclater, J. G.; Jaupart, C.; Galson, D. (1980): The heat flow through oceanic and continental crust and the heat loss of the Earth. In: Rev. Geophys. 18 (1), S. 269.';
    ref_hr = 'arbitrary';
    ref_thickness_mantle = 'arbitrary';
    ref_density_mantle = 'estimated from the PREM model Dziewonski, A. M.; Anderson, D. L. (1981): Preliminary reference Earth model. In: Physics of the Earth and Planetary Interiors 25 (4), S. 297–356.';
    ref_heatflow_baseofcrust = 'Sclater, J. G.; Jaupart, C.; Galson, D. (1980): The heat flow through oceanic and continental crust and the heat loss of the Earth. In: Rev. Geophys. 18 (1), S. 269.';
    ref_thermalconductivity_mantle = 'Sclater, J. G.; Jaupart, C.; Galson, D. (1980): The heat flow through oceanic and continental crust and the heat loss of the Earth. In: Rev. Geophys. 18 (1), S. 269.';
    ref_radiogenicheatproduction = 'calculated';
elseif choice == 1
    % CONTINENTAL
    %crust
    thickness_crust = 40; %km 
    density_crust = 2830; %kg/m³ 
    T0_C = 10; %°C surface temperature
    q0 = 46; %mW m-2 heat flow surface 
    k1 = 2.51; %W m-1 K-1 thermal conductivity crust
    hr_km = 14; %km
    %mantle
    thickness_mantle = 60;
    density_mantle = 3380; %kg/m³
    qr = 19; %mW m-2 heat flow base of crust 
    k2 = 3.35; %W m-1 K-1 thermal conductivity mantle
    ref_thickness_crust = 'Philpotts, A.; Ague, J. (2009): Principles of Igneous and Metamorphic Petrology. Cambridge: Cambridge University Press.';
    ref_density_crust = 'Christensen, N. I.; Mooney, W. D. (1995): Seismic velocity structure and composition of the continental crust: A global view. In: J. Geophys. Res. 100 (B6), S. 9761–9788.';
    ref_surfacetemp = 'arbitrary';
    ref_heat_flowsurface = 'Sclater, J. G.; Jaupart, C.; Galson, D. (1980): The heat flow through oceanic and continental crust and the heat loss of the Earth. In: Rev. Geophys. 18 (1), S. 269.';
    ref_thermalconductivity_crust = 'Sclater, J. G.; Jaupart, C.; Galson, D. (1980): The heat flow through oceanic and continental crust and the heat loss of the Earth. In: Rev. Geophys. 18 (1), S. 269.';
    ref_hr = 'arbitrary';
    ref_thickness_mantle = 'arbitrary';
    ref_density_mantle = 'estimated from the PREM model Dziewonski, A. M.; Anderson, D. L. (1981): Preliminary reference Earth model. In: Physics of the Earth and Planetary Interiors 25 (4), S. 297–356.';
    ref_heatflow_baseofcrust = 'Sclater, J. G.; Jaupart, C.; Galson, D. (1980): The heat flow through oceanic and continental crust and the heat loss of the Earth. In: Rev. Geophys. 18 (1), S. 269.';
    ref_thermalconductivity_mantle = 'Sclater, J. G.; Jaupart, C.; Galson, D. (1980): The heat flow through oceanic and continental crust and the heat loss of the Earth. In: Rev. Geophys. 18 (1), S. 269.';
    ref_radiogenicheatproduction = 'calculated';
elseif choice == 2
    % OCEANIC
    %crust
    thickness_crust = 10; %km 
    density_crust = 2900; %kg/m³
    T0_C = 10; %°C surface temperature
    q0 = 34; %mW m-2 heat flow surface 
    k1 = 2.51; %W m-1 K-1 thermal conductivity crust
    hr_km = 10; %km
    %mantle
    thickness_mantle = 90;
    density_mantle = 3380; %kg/m³
    qr = 25.1; %mW m-2 heat flow base of crust 
    k2 = 3.35; %W m-1 K-1 thermal conductivity mantle
    ref_thickness_crust = 'Philpotts, A.; Ague, J. (2009): Principles of Igneous and Metamorphic Petrology. Cambridge: Cambridge University Press.';
    ref_density_crust = 'Carlson, R. L.; Herrick, C. N. (1990): Densities and porosities in the oceanic crust and their variations with depth and age. In: J. Geophys. Res. 95 (B6), S. 9153';
    ref_surfacetemp = 'arbitrary';
    ref_heat_flowsurface = 'Sclater, J. G.; Jaupart, C.; Galson, D. (1980): The heat flow through oceanic and continental crust and the heat loss of the Earth. In: Rev. Geophys. 18 (1), S. 269.';
    ref_thermalconductivity_crust = 'Sclater, J. G.; Jaupart, C.; Galson, D. (1980): The heat flow through oceanic and continental crust and the heat loss of the Earth. In: Rev. Geophys. 18 (1), S. 269.';
    ref_hr = 'arbitrary';
    ref_thickness_mantle = 'arbitrary';
    ref_density_mantle = 'estimated from the PREM model Dziewonski, A. M.; Anderson, D. L. (1981): Preliminary reference Earth model. In: Physics of the Earth and Planetary Interiors 25 (4), S. 297–356.';
    ref_heatflow_baseofcrust = 'Sclater, J. G.; Jaupart, C.; Galson, D. (1980): The heat flow through oceanic and continental crust and the heat loss of the Earth. In: Rev. Geophys. 18 (1), S. 269.';
    ref_thermalconductivity_mantle = 'Sclater, J. G.; Jaupart, C.; Galson, D. (1980): The heat flow through oceanic and continental crust and the heat loss of the Earth. In: Rev. Geophys. 18 (1), S. 269.';
    ref_radiogenicheatproduction = 'calculated';
end


p_degree = 4; %degree of polynamial for fitting the geotherm



%% convert units, create arrays and calculate stuff
dz = 0.1; %km
g = 9.81; %m s-2
T0_K = T0_C+273.15; %°C to K
thickness_total = thickness_crust+thickness_mantle; %km
z_crust_km = (0:dz:thickness_crust)';
z_mantle_km = (thickness_crust+dz:dz:thickness_total)';
z_total_km = (0:dz:thickness_total)'; %km
T_K = zeros(length(z_total_km):1);
A = (q0-qr)/hr_km; %radiogenic heat production (uW/m³)

%%
P_Pa = zeros(numel(z_total_km),1);
density_crust_array = zeros(numel(z_crust_km),1);
density_mantle_array = zeros(numel(z_mantle_km),1);

%% calculate T at depth z in the crust
for i = 1:length(z_crust_km)
    T_K(i) = T0_K+(qr*z_crust_km(i)/k1)+(q0-qr)*hr_km/k1*(1-exp(-z_crust_km(i)/hr_km));
end

%% calculate T at depth z in the mantle
for i = 1:length(z_mantle_km)
    T_K(length(z_crust_km)+i) = T_K(length(z_crust_km))+(z_mantle_km(i)-z_crust_km(end))/k2*qr;
end

%% calculate lithostatic P at depth z
%create arrays of density for integration along depth
for k = 1:numel(z_crust_km)
    density_crust_array(k,:) = density_crust;
end
for k = 1:numel(z_mantle_km)
    density_mantle_array(k,:) = density_mantle;
end
density_total = [density_crust_array;density_mantle_array];
z_total_m = z_total_km*1000;

for n = 2:numel(z_total_km)
    dens = density_total(1:n);
    z_m = z_total_m(1:n);
    P_Pa(n,:) = trapz(z_m,dens)*g;
end


%% calculate fO2 at depth z (in dependence of T)



%O'Neill and Pownceby (1993) Contrib. Mineral. Petrol. 114:296-314
log10fO2_NNO = ((-478967+248.514.*T_K-9.7961.*T_K.*log(T_K))./(2.303*8.31441*T_K))'; %700-1700K
%O'Neill (1987) Am.Min. 72:67-75
log10fO2_QMF =((-587474+1584.427.*T_K-203.3164.*T_K.*log(T_K)+0.092710.*(T_K.^2))./(2.303.*8.31441.*T_K))'; %900-1420K


%% convert to handy units
T_K = T_K';
T_C = T_K-273.15;

P_GPa = P_Pa*1E-9;
P_kbar = P_Pa*1E-8;
P_bar = P_kbar*1000;

%% fit a polynomial to the PT points
%this can be used for the geotherm feature in PERPLE_X

[p,S] = polyfit(T_K,P_bar,p_degree);
p_P_bar = polyval(p,T_K);
[r2,rmse] = rsquare(P_bar,p_P_bar);
p_P_GPa = p_P_bar/10000;
p_txt = num2str(flip(p)');


%% plot
figure('Name','Geotherm','NumberTitle','off')
subplot(2,3,1)
plot(T_C,z_total_km,'-','LineWidth',2,'Color','k')
set(gca,'XAxisLocation','top')
set(gca,'Ydir','reverse')
xlabel('temperature °C')
ylabel('depth km')

subplot(2,3,2)
plot(P_GPa,z_total_km,'-','LineWidth',2,'Color','k')
set(gca,'XAxisLocation','top')
set(gca,'Ydir','reverse')
xlabel('lithostatic pressure GPa')
ylabel('depth km')

subplot(2,3,3)
plot(T_C,P_GPa,'-','LineWidth',2,'Color','k')
hold on;
plot(T_C,p_P_GPa,'-','LineWidth',1.5,'Color','b')
set(gca,'XAxisLocation','top')
set(gca,'Ydir','reverse')
xlabel('temperature °C')
ylabel('lithostatic pressure GPa')
ylim([0 max(P_GPa)])
r2_txt = num2str(r2);
legend_txtfit = strcat('polyfit'," ",'r^2'," = ",r2_txt);
legend('PT',legend_txtfit)

subplot(2,3,4)
plot(log10fO2_NNO,z_total_km,'-','LineWidth',2,'Color','k')
hold on;
plot(log10fO2_QMF,z_total_km,'--','LineWidth',2,'Color','k')
hold off;
set(gca,'XAxisLocation','top')
set(gca,'Ydir','reverse')
xlabel('log10fO2')
ylabel('depth km')
legend('NNO','QMF')

subplot(2,3,5)
plot(z_total_km,density_total,'-','LineWidth',2,'Color','k')
set(gca,'XAxisLocation','top')
xlabel('depth km')
ylabel('density kg/m³')
ylim([(min(density_total)-max(density_total)/100) (max(density_total)+max(density_total)/100)])

subplot(2,3,6)
text(0.5,0.5,p_txt); axis off


%% write output
header = {'depth (m)', 'depth (km)','density (kg/m³)','T (K)','T (C)','P (GPa)','P (kbar)','log10fO2 (NNO)','log10fO2 (QMF)'};
data = table([z_total_m,z_total_km,density_total,T_K,T_C,P_GPa,P_kbar,log10fO2_NNO,log10fO2_QMF]);

filename = strcat(filename,'.xlsx');
writecell(header,filename,'Sheet',1,'Range','A1');
writetable(data,filename,'Sheet',1,'Range','A2','WriteVariableNames',0);

header_info = {'thickness crust (km)';'density crust (kg m-3)';'surface temperature (°C)';'surface heat flow (mW m-2)';'thermal conductivity crust (W m-1 K-1)';'hr (km)';'thickness mantle (km)';'density mantle (kg m-3)';'heat flow base of crust (mW m-2)';'thermal conductivity mantle (W m-1 K-1)';'radiogenic heat production (uW/m³)'};
data_info = table([thickness_crust;density_crust;T0_C;q0;k1;hr_km;thickness_mantle;density_mantle;qr;k2;A]);
reference = {'geotherm calculation after Sclater, J. G.; Jaupart, C.; Galson, D. (1980) In: Rev. Geophys. 18 (1), S. 269.'};
references_values = {ref_thickness_crust;ref_density_crust;ref_surfacetemp;ref_heat_flowsurface;ref_thermalconductivity_crust;ref_hr;ref_thickness_mantle;ref_density_mantle;ref_heatflow_baseofcrust;ref_thermalconductivity_mantle;ref_radiogenicheatproduction};

writecell(header_info,filename,'Sheet',2,'Range','A2');
writetable(data_info,filename,'Sheet',2,'Range','B2','WriteVariableNames',0);
writecell(reference,filename,'Sheet',2,'Range','A1');
writecell(references_values,filename,'Sheet',2,'Range','C2');

