%This script adapts the code structure of Huizenga - Computers &
%Geosciences 31 (2005) 797-800. The fugacity coefficients are loaded from
%external .mat files that contain data from Shi and Saxena (1992) Am. Min
%77, 1038-1049. These are interpolated to a spacing of 1 T °C and 0.01 kbar
%(or 0.001 GPa) (changes in resolution are possible). The right fugacity
%coefficient is then picked from the interpolated dataset using the input
%P-T values. ("y" = fugacity coefficient). This version allows to compute
%fluid compositions along a geotherm (P,T,fO2 path).

%This version uses a geotherm that is read from an xlsx file that is produced by
%the geotherm script

clear variables;
%% input

choice = 1; %use interpolation of original data(0) or extrapolated data towards higher P (35 kbar) and lower T (100 °C) (1)
filename = 'Adiabat.xlsx';

geotherm = readmatrix(filename,'Sheet',1);
T_C_input = round(geotherm(:,5));
P_GPa_input = geotherm(:,6);
P_kbar_input = round(P_GPa_input*10,2); %this converts P(GPa) to P(kbar) rounded to 2 decimal places as used in the P-T grid of the y-data
nodes = numel(T_C_input);


a_c_input = zeros(1,nodes);
log10fO2_QMF_input = zeros(1,nodes);
for i = 1:nodes
    a_c_input(i,:) = 1; %carbon activity
    log10fO2_QMF_input(i,:) = 0; %oxygen fugacity relative to log10 QMF
end

% some pre-calculations for the interpolation method


%% load original fugacity coefficients 
%data from Shi and Saxena (1992, Am. Min. 77,1038-1049)
%format: rows = increasing T in C; columns = increasing P in kbar

if choice == 0
load('fugacity_coefficient_H2O.mat')
load('fugacity_coefficient_CO2.mat')
load('fugacity_coefficient_CH4.mat')
load('fugacity_coefficient_H2.mat')
load('fugacity_coefficient_CO.mat')
load('fugacity_coefficient_T_C.mat')
load('fugacity_coefficient_P_kbar.mat')


%% interpolate fugacity coefficient data
%this is done by 2D interpolation over a T-P grid with certain node spacing
%determined by dT_interp and dP_interp. 

%you can change the spacing for interpolation but this might lead to
%problems in later steps (e.g. finding the input P or T value in the
%interpolated P-T space - e.g. rounding problems...)
dT_C_interp = 1; %interpolation spacing °C
T_C_min_y = min(fugacity_coefficient_T_C); %minimum T °C of y dataset
T_C_max_y = max(fugacity_coefficient_T_C); %maximum T °C of y dataset
T_C_interp  = (T_C_min_y:dT_C_interp:T_C_max_y); %T °C used for interpolation 

dP_kbar_interp = 1/100; %interpolation spacing kbar
P_kbar_min_y = min(fugacity_coefficient_P_kbar); %minimum P kbar of y dataset
P_kbar_max_y = max(fugacity_coefficient_P_kbar); %maximum P kbar of y dataset
P_kbar_interp = (P_kbar_min_y:dP_kbar_interp:P_kbar_max_y); % T kbar used for interpolation
P_kbar_interp = round(P_kbar_interp,2);


% create a grids for 2D interpolation
[T_C_grid,P_kbar_grid] = meshgrid(fugacity_coefficient_T_C,fugacity_coefficient_P_kbar);
[T_C_interp_grid,P_kbar_interp_grid] = meshgrid(T_C_interp,P_kbar_interp);

% 2D interpolation of fugacity coefficient data
fug_coeff_interp_H2O = interp2(T_C_grid,P_kbar_grid,fugacity_coefficient_H2O',T_C_interp_grid,P_kbar_interp_grid);
fug_coeff_interp_CO2 = interp2(T_C_grid,P_kbar_grid,fugacity_coefficient_CO2',T_C_interp_grid,P_kbar_interp_grid);
fug_coeff_interp_CH4 = interp2(T_C_grid,P_kbar_grid,fugacity_coefficient_CH4',T_C_interp_grid,P_kbar_interp_grid);
fug_coeff_interp_H2 = interp2(T_C_grid,P_kbar_grid,fugacity_coefficient_H2',T_C_interp_grid,P_kbar_interp_grid);
fug_coeff_interp_CO = interp2(T_C_grid,P_kbar_grid,fugacity_coefficient_CO',T_C_interp_grid,P_kbar_interp_grid);

else
    load('yH2O_extrapolated.mat')
    load('yCH4_extrapolated.mat')
    load('yCO_extrapolated.mat')
    load('yCO2_extrapolated.mat')
    load('yH2_extrapolated.mat')
    load('fugacity_coefficient_T_C.mat')
    load('fugacity_coefficient_P_kbar.mat')
    
    fug_coeff_interp_H2O = fug_coeff_final_H2O;
    fug_coeff_interp_CH4 = fug_coeff_final_CH4;
    fug_coeff_interp_CO = fug_coeff_final_CO;
    fug_coeff_interp_CO2 = fug_coeff_final_CO2;
    fug_coeff_interp_H2 = fug_coeff_final_H2;
    
    dT_C_interp = 1; %interpolation spacing °C
    T_C_min_y = 100; %minimum T °C of y dataset
    T_C_max_y = 1000; %maximum T °C of y dataset
    T_C_interp  = (T_C_min_y:dT_C_interp:T_C_max_y); %T °C used for interpolation 

    dP_kbar_interp = 1/100; %interpolation spacing kbar
    P_kbar_min_y = 1; %minimum P kbar of y dataset
    P_kbar_max_y = 35; %maximum P kbar of y dataset
    P_kbar_interp = (P_kbar_min_y:dP_kbar_interp:P_kbar_max_y); % T kbar used for interpolation
    P_kbar_interp = round(P_kbar_interp,2);
end
%% convert units
%convert units
P_kbar = P_GPa_input*10;
P_bar = P_GPa_input*1E+4;
T_K_input = T_C_input+273;
P_GPa_interp = P_kbar_interp/10;

%% creates arrays
fO2_fluid = zeros(1,nodes);

%% find fugacity coefficient at input P-T
for i = 1:nodes
    
    fO2_fluid(i) = 10^((-25738/T_K_input(i))+9+0.091*((P_bar(i)-1)./T_K_input(i))+log10fO2_QMF_input(i));
 
    if ismember(T_C_input(i),T_C_interp) && ismember(P_kbar_input(i),P_kbar_interp)
    
        [~,T_C_idxcol(i)] = find(T_C_input(i)==T_C_interp);
        [~,P_kbar_idxcol(i)] = find(P_kbar_input(i)==P_kbar_interp);

        y_H2O(i) = fug_coeff_interp_H2O(P_kbar_idxcol(i),T_C_idxcol(i));
        y_CO2(i) = fug_coeff_interp_CO2(P_kbar_idxcol(i),T_C_idxcol(i));
        y_CH4(i) = fug_coeff_interp_CH4(P_kbar_idxcol(i),T_C_idxcol(i));
        y_H2(i) = fug_coeff_interp_H2(P_kbar_idxcol(i),T_C_idxcol(i));
        y_CO(i) = fug_coeff_interp_CO(P_kbar_idxcol(i),T_C_idxcol(i));

        %% equilibrium constants at input (works)

        K1(i) = 10^(14751/T_K_input(i)-4.535); %eq.5 
        K2(i) = 10^((12510/T_K_input(i))-0.979*log10(T_K_input(i))+0.483); %eq.6
        K3(i) = 10^((41997/T_K_input(i))+0.719*log10(T_K_input(i))-2.404); %eq.7
        K4(i) = 10^((20586/T_K_input(i))+0.0421+0.0276*(P_bar(i)-1)/T_K_input(i)); %eq.8

        %% intermediate calculations (works)
        max_fO2(i) = y_CO2(i)*P_bar(i)/(K4(i)*a_c_input(i)); %maximum fO2 at which C-O-H fluid can exist for the given PT  
        max_log10fO2(i) = log10(max_fO2(i)); 

        C1(i) = ((a_c_input(i)*K4(i))/(y_CO2(i)*P_bar(i))); %C1 in eq.10 
        C2(i) = (y_CO2(i)/(K1(i)*y_CO(i))); %C2 in eq.11 
        C3(i) = (y_H2O(i)/(K2(i)*y_H2(i))); %C3 in eq.12 
        C4(i) = ((y_CO2(i)*(y_H2O(i)^2)*(P_bar(i)^2))/(K3(i)*y_CH4(i))); %C4 in eq.13 

        %% calculate molar fractions
        if fO2_fluid(i) < max_fO2(i)
            X_CO2(i) = C1(i)*fO2_fluid(i); %eq.10 works
            X_CO(i) = C2(i)*(X_CO2(i)/(fO2_fluid(i)^(1/2))); %eq.11 works
            a(i) = C1(i)*C4(i)/(fO2_fluid(i));
            b_molefrac(i) = (C3(i)*(fO2_fluid(i)^(-1/2))+1);
            c(i) = C1(i)*fO2_fluid(i)*(1+C2(i)*(fO2_fluid(i)^(-1/2)));
            d(i) = -1;
            X_H2O(i) = (-b_molefrac(i)+sqrt((b_molefrac(i)^2)-4*a(i)*(c(i)+d(i))))/(2*a(i)); %solved eq.14 slightly different but why?
            X_H2(i) = C3(i)*(X_H2O(i)/(fO2_fluid(i)^(1/2))); %eq.12
            X_CH4(i) = C4(i)*((X_CO2(i)*(X_H2O(i)^2))/(fO2_fluid(i)^2)); %eq.13
        elseif fO2_fluid(i) > max_fO2(i)
            X_CO2(i) = 1; %mole fraction CO2
            X_CO(i) = 0; %mole fraction CO
            X_H2O(i) = 0; %mole fraction H2O
            X_H2(i) = 0; %mole fraction H2
            X_CH4(i) = 0; %mole fraction CH4
        end
        X_total(i) = X_H2O(i)+X_CO2(i)+X_CH4(i)+X_H2(i)+X_CO(i); %total mole fraction 

        %% calculate atomic fraction

        n_C(i) = (X_CO2(i)+X_CH4(i)+X_CO(i))/(3*X_H2O(i)+3*X_CO2(i)+5*X_CH4(i)+2*X_H2(i)+2*X_CO(i)); % atomic fraction carbon
        n_O(i) = (X_H2O(i)+2*X_CO2(i)+X_CO(i))/(3*X_H2O(i)+3*X_CO2(i)+5*X_CH4(i)+2*X_H2(i)+2*X_CO(i)); %atomic fraction oxygen
        n_H(i) = (2*X_H2O(i)+4*X_CH4(i)+2*X_H2(i))/(3*X_H2O(i)+3*X_CO2(i)+5*X_CH4(i)+2*X_H2(i)+2*X_CO(i)); %atomic fraction hydrogen
        n_total(i) = n_C(i)+n_O(i)+n_H(i);

        %% calculate ratios

        ratio_co2_co4andco2(i) = X_CO2(i)/(X_CO2(i)+X_CH4(i));
        ratio_H_O(i) = n_H(i)/n_O(i);
        ratio_O_OandH(i) = n_O(i)/(n_O(i)+n_H(i));
    
    else
        T_C_idxcol(i) = NaN;
        P_kbar_idxcol(i) = NaN;

        y_H2O(i) = NaN;
        y_CO2(i) = NaN;
        y_CH4(i) = NaN;
        y_H2(i) = NaN;
        y_CO(i) = NaN;

        %% equilibrium constants at input (works)

        K1(i) = NaN; 
        K2(i) = NaN;
        K3(i) = NaN;
        K4(i) = NaN;

        %% intermediate calculations (works)
        max_fO2(i) = NaN; %maximum fO2 at which C-O-H fluid can exist for the given PT  
        max_log10fO2(i) = NaN;

        C1(i) = NaN; %C1 in eq.10 
        C2(i) = NaN; %C2 in eq.11 
        C3(i) = NaN; %C3 in eq.12 
        C4(i) = NaN; %C4 in eq.13 

        %% calculate molar fractions
        X_CO2(i) = NaN; %mole fraction CO2
        X_CO(i) = NaN; %mole fraction CO
        X_H2O(i) = NaN; %mole fraction H2O
        X_H2(i) = NaN; %mole fraction H2
        X_CH4(i) = NaN; %mole fraction CH4

        X_total(i) = NaN; %total mole fraction 

        %% calculate atomic fraction

        n_C(i) = NaN; % atomic fraction carbon
        n_O(i) = NaN; %atomic fraction oxygen
        n_H(i) = NaN; %atomic fraction hydrogen
        n_total(i) = NaN;

        %% calculate ratios

        ratio_co2_co4andco2(i) = NaN;
        ratio_H_O(i) = NaN;
        ratio_O_OandH(i) = NaN;
          
        
    end
    X_O(i) = 1/(ratio_H_O(i)+1);
    f_H2O(i) = X_H2O(i)*y_H2O(i)*P_GPa_input(i)*1E+9;
    f_CO(i) = X_CO(i)*y_CO(i)*P_GPa_input(i)*1E+9;
    f_CO2(i) = X_CO2(i)*y_CO2(i)*P_GPa_input(i)*1E+9;
    f_CH4(i) = X_CH4(i)*y_CH4(i)*P_GPa_input(i)*1E+9;
    f_H2(i) = X_H2(i)*y_H2(i)*P_GPa_input(i)*1E+9;
end

log10f_H2O = log10(f_H2O);
log10f_CO = log10(f_CO);
log10f_CO2 = log10(f_CO2);
log10f_CH4 = log10(f_CH4);
log10f_H2 = log10(f_H2);

%% check whether all input values were found
[~,idxfindPinput,idxfindPinterp] = intersect(P_kbar_input,P_kbar_interp);

%% plot
figure
subplot(2,2,1)
meshc(T_C_interp,P_GPa_interp,fug_coeff_interp_H2O);
xlabel('temperature °C');
ylabel('pressure GPa');
zlabel('yH_2O');
title('fugacity coefficient H_2O');

subplot(2,2,2)
plot(T_C_input,P_GPa_input,'-','Color','k','LineWidth',3)
set(gca,'Ydir','reverse')
xlabel('temperature °C');
ylabel('pressure GPa');
title('geotherm')

subplot(2,2,3)
p1a=scatter3(T_C_input,P_GPa_input,X_H2O,2,'o','MarkerFaceColor','k','MarkerEdgeColor','k');
hold on;
line(T_C_input,P_GPa_input,X_H2O,'Color','k')
hold on;
p2a=scatter3(T_C_input,P_GPa_input,X_CH4,2,'o','MarkerFaceColor','r','MarkerEdgeColor','r');
hold on;
line(T_C_input,P_GPa_input,X_CH4,'Color','r')
hold on;
p3a=scatter3(T_C_input,P_GPa_input,X_CO,2,'o','MarkerFaceColor','b','MarkerEdgeColor','b');
hold on;
line(T_C_input,P_GPa_input,X_CO,'Color','b')
hold on;
p4a=scatter3(T_C_input,P_GPa_input,X_CO2,2,'o','MarkerFaceColor','g','MarkerEdgeColor','g');
hold on;
line(T_C_input,P_GPa_input,X_CO2,'Color','g')
hold on;
p5a=scatter3(T_C_input,P_GPa_input,X_H2,2,'o','MarkerFaceColor','c','MarkerEdgeColor','c');
hold on;
line(T_C_input,P_GPa_input,X_H2,'Color','c')
hold on;
xlabel('temperature °C')
ylabel('pressure GPa')
zlabel('species molar fraction')
legend([p1a,p2a,p3a,p4a,p5a],{'H_2O','CH_4','CO','CO_2','H_2'})


subplot(2,2,4)
p1b=scatter3(T_C_input,P_GPa_input,log10f_H2O,2,'o','MarkerFaceColor','k','MarkerEdgeColor','k');
hold on;
line(T_C_input,P_GPa_input,log10f_H2O,'Color','k')
hold on;
p2b=scatter3(T_C_input,P_GPa_input,log10f_CH4,2,'o','MarkerFaceColor','r','MarkerEdgeColor','r');
hold on;
line(T_C_input,P_GPa_input,log10f_CH4,'Color','r')
hold on;
p3b=scatter3(T_C_input,P_GPa_input,log10f_CO,2,'o','MarkerFaceColor','b','MarkerEdgeColor','b');
hold on;
line(T_C_input,P_GPa_input,log10f_CO,'Color','b')
hold on;
p4b=scatter3(T_C_input,P_GPa_input,log10f_CO2,2,'o','MarkerFaceColor','g','MarkerEdgeColor','g');
hold on;
line(T_C_input,P_GPa_input,log10f_CO2,'Color','g')
hold on;
p5b=scatter3(T_C_input,P_GPa_input,log10f_H2,2,'o','MarkerFaceColor','c','MarkerEdgeColor','c');
hold on;
line(T_C_input,P_GPa_input,log10f_H2,'Color','c')
hold on;
xlabel('temperature °C')
ylabel('pressure GPa')
zlabel('species log_{10}fugacity')
legend([p1b,p2b,p3b,p4b,p5b],{'H_2O','CH_4','CO','CO_2','H_2'})

%% write data
header = {'yH_2O','X H_2O','f(H_2O)'};
data = [y_H2O',X_H2O',f_H2O'];
data = table(data);
writetable(data,filename,'Sheet',1,'Range','J1');
writecell(header,filename,'Sheet',1,'Range','J1');