clear variables

calcreeq = 0;

%parameter for CT
% p1a = 9.4663E5;
% p1b = -3.399;
% q1a = 7.3650E2;
% q1b = -1.4375;
% q2a = 1.0861E4;
% q2b = -3.3604;

%parameter for OC
p1a = 9.6171E6;
p1b = -8.8003;
q1a = 2.0662E4;
q1b = -7.0677;
q2a = 1.1485E5;
q2b = -8.6851;

sizes = (0:0.01:2.5);
cr = (0.1:0.1:1000); %make in log-scale

cr1 = (0.1:0.001:1);
cr2 = (1.01:0.01:10);
cr3 = (10.1:0.10:100);
cr4 = (101:1.00:1000);
cr = [cr1,cr2,cr3,cr4];

[X,Y] = meshgrid(cr,sizes);

if calcreeq == 0
    for i = 1:numel(sizes)
        for k = 1:numel(cr)
            reeq(i,k) = (p1a*sizes(i)^p1b)/((cr(k)^2)+(q1a*(sizes(i)^q1b)*cr(k))+(q2a*sizes(i)^q2b));
        end
    end
else
end

figure
[W,Z] = contourf(log10(X),Y,reeq,'LineColor','white','LineWidth',1);
colorbar 
colormap(bone)
xlabel('cooling rate (°C/yr)');
ylabel('crystal size (mm)');
contours = [10,20,30,40,50,60,70,80,90];
clabel(W,Z,contours,'FontSize',15,'Color','white');

dlmwrite('output.txt',reeq);

